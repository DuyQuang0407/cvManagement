package quang.cao.cvmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CvManagerApplication.class, args);
    }

}
